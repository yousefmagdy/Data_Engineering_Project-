Q: Why only Airflow folder without postgress folder?
The postgress database is included in the same folder as Airflow, its container is specified in the same docker-compose.yaml file as Airflow.
This is good because:
- I can create a different database service than the one used by Airflow, just give it a different name.
- It's easier because I don't have to create a network between the two containers(Airflow and Postgress).

# Links/URLs:
airflow 	- localhost:8080
dashboard 	- localhost:8001

Q: Why did we include 'vehicles.csv' and 'vehicles_lot.csv' in the data folder?
Because the data we scrapped originally its size exceeds 3 GB, This is because it contained every year from 1979-2021.
This will be too much to upload for you, or download inside the DAG task.
So we decided to excute Milestone 2 cleaning code on the big dataset, and use the cleaned data (vehicles.csv, vehicles_lot.csv) for Milestone 3.
