import pandas as pd
import numpy as np
from scipy import stats
from sklearn import preprocessing
import os

def clean(csvPath):
	# %%
	ds = pd.read_csv(csvPath, index_col='accident_index',
					parse_dates=['date'], infer_datetime_format=True)

	# %%
	ds.drop(['accident_year', 'accident_reference', 'lsoa_of_accident_location',
			'did_police_officer_attend_scene_of_accident', 'longitude', 'latitude'], axis=1, inplace=True)


	# %%
	ColumnsContainDataMissing = [
		'pedestrian_crossing_human_control',
		'pedestrian_crossing_physical_facilities',
		'light_conditions',
		'road_surface_conditions',
		'special_conditions_at_site',
		'carriageway_hazards',
		'trunk_road_flag',
		'junction_control',
		'junction_detail'
	]
	ds[ColumnsContainDataMissing] = ds[ColumnsContainDataMissing].replace(
		'Data missing or out of range', np.NaN)

	ColumnsContainNegOne = [
		'second_road_class',
		'local_authority_ons_district',
		'local_authority_highway'
	]
	ds[ColumnsContainNegOne] = ds[ColumnsContainNegOne].replace('-1', np.NaN)


	# Replace the roads which have no numbers with string "0" in second_road_number and first_road_number, later will be converted to numeric integer
	ColumnsToReplace = ["second_road_number", "first_road_number"]
	ds[ColumnsToReplace] = ds[ColumnsToReplace].replace(
		"first_road_class is C or Unclassified. These roads do not have official numbers so recorded as zero ", "0")

	# %%
	# Percentage of values missing in each column
	col_perc_missing = ds.isnull().mean().sort_values(ascending=False)*100

	# %% [markdown]
	# Remove rows with missing values that represent less than 2% of the data

	# %%
	for columnName in col_perc_missing.index:
		if col_perc_missing[columnName] < 2:
			ds.dropna(subset=[columnName], inplace=True)

	# %%
	columns_numerical = ds.select_dtypes(include=np.number).columns


	# %%
	for colname in columns_numerical:
		Q1 = ds[colname].quantile(0.25)
		Q3 = ds[colname].quantile(0.75)
		IQR = Q3 - Q1
		cut_off = IQR * 1.5
		lower = Q1 - cut_off
		upper = Q3 + cut_off

		df1 = ds[colname][ds[colname] >= upper]
		df2 = ds[colname][ds[colname] <= lower]
		df3 = ds[(ds[colname] <= upper) & (ds[colname] >= lower)]

		count_recods = ds.shape[0]
		count_removed = count_recods - df3.shape[0]

		# ds = ds[(ds[colname] <= upper) & (ds[colname] >= lower)]


	# %%
	for colname in columns_numerical:
		z = np.abs(stats.zscore(ds[colname]))
		count_recods = ds.shape[0]
		count_removed = ds[z >= 4].shape[0]
		# remove outliers above 4 standard deviations
		ds = ds[z < 4]
		# print("{} \t to be removed \t{} \t{}%".format(
		#     colname, count_removed, round((count_removed)*100 / ds.shape[0], 2)))
		# print()


	# %% [markdown]
	# ## Findings and conclusions

	# %% [markdown]
	# Stated above

	# %% [markdown]
	# # 4 - Data transformation

	# %% [markdown]
	# Fix the data types of the columns


	# %% [markdown]
	# Convert column `first_road_number` and `second_road_number` to a numeric datatype.<br/>
	# Convert column `time` into timedelta datatype

	# %%
	ds['first_road_number'] = pd.to_numeric(
		ds['first_road_number'], errors='coerce')
	ds['second_road_number'] = pd.to_numeric(
		ds['second_road_number'], errors='coerce')
	#
	ds['time'] = pd.to_timedelta(ds['time'] + ":00")

	# %%
	columns_numerical = ds.select_dtypes(include=np.number).columns


	# %% [markdown]
	# ## 4.1 - Discretization

	# %% [markdown]
	# Add a new column for the `week_number`

	# %%
	# ds['week_number'] = ds['date'].dt.isocalendar().week
	ds['week_number'] = ds['date'].dt.strftime('%U').to_numpy().astype(int)

	# %%
	df_week_start_end = ds.groupby('week_number').agg({'date': ['min', 'max']})

	df_week_start_end.columns = ['week_start', 'week_end']
	df_week_start_end.to_csv('/opt/airflow/data/week_start_end.csv')

	# add to the dataset

	ds = ds.reset_index().merge(df_week_start_end, on='week_number',
								how='left').set_index('accident_index')
	# pd.merge(ds, df_week_start_end, on='week_number', how='left')


	# %% [markdown]
	# ## 4.11 - Findings and conclusions

	# %% [markdown]
	# Stated Above

	# %% [markdown]
	# ## 4.2 - Encoding


	# %%
	# encodes a given column with a given maping dictionary for example: {'tokyo': 1, 'paris': 2, 'amsterdam': 3}


	def ordinalLabelEncoder(df, columnName, mapping):
		df[columnName] = df[columnName].map(mapping, na_action='ignore')

	# data = pd.DataFrame(columns=['city'], data=["tokyo", "paris", "paris",  "amsterdam"])
	# mapping = {'tokyo': 0, 'paris': 1, 'amsterdam': 2}
	# ordinalLabelEncoder(data, 'city', mapping)

	# data

	# %%

	# returns a data frame of the mappings, label and the coded value


	def mapping_to_df(mapping):
		df = pd.DataFrame(columns=['Code'], data=mapping.values())
		df.index = mapping.keys()
		return df

	# mapping = {'Slight': 0, 'Serious': 1, 'Fatal': 2}
	# mapping_to_df(mapping ).to_csv('accident_severity.csv')

	# %% [markdown]
	# Create a folder to store the encoded labels csv files


	# %%
	path_encoding_labels = '/opt/airflow/data/encoding_labels/'
	if not os.path.exists(path_encoding_labels):
		os.mkdir(path_encoding_labels)

	# %% [markdown]
	# How many categories in each categorical column

	# %%
	ds.select_dtypes(include='object').nunique().sort_values(ascending=False)

	# %% [markdown]
	# We'll not use One hot encoding, since the number of categories is very large.
	#
	# Encode categorical columns as numbers using Label encoding

	# %%
	ordinal_custom_mapping = {
		'accident_severity': {'Slight': 0, 'Serious': 1, 'Fatal': 2},
		'day_of_week': {'Monday': 0, 'Tuesday': 1, 'Wednesday': 2, 'Thursday': 3, 'Friday': 4, 'Saturday': 5, 'Sunday': 6},
	}

	for colname in ordinal_custom_mapping:
		ordinalLabelEncoder(ds, colname, ordinal_custom_mapping[colname])
		# Save lookup tables
		mapping_to_df(ordinal_custom_mapping[colname]).to_csv(
			path_encoding_labels + colname + '.csv')


	# %%
	columns_categorical = ds.select_dtypes('object').columns


	# %% [markdown]
	# Fill null values of numerical columns with -1
	# <br/>
	# Fill null values of categorical columns with `Not Available`

	# %%
	for colname in columns_numerical:
		# this skips the Time column, eventhough it does not have any null values
		if(ds[colname].isnull().sum() > 0):
			ds[colname] = ds[colname].fillna(-1)
	# ds[columns_numerical] = ds[columns_numerical].fillna(-1)

	# %%
	# columns which contain nulls
	df_missingdata = ds.columns[ds.isnull().any()].tolist()

	# fill missing values with 'Not Available'
	# ds[df_missingdata] = ds[df_missingdata].fillna('Not Available')
	ds[columns_categorical] = ds[columns_categorical].fillna('Not Available')

	# %%


	for column in columns_categorical:
		if(column in ordinal_custom_mapping):
			continue  # skip ordinal columns, they are already encoded

		# ds[column] = preprocessing.LabelEncoder().fit_transform(ds[column])
		encoder = preprocessing.LabelEncoder()

		ds[column] = encoder.fit_transform(ds[column])

		mapping = dict(zip(encoder.classes_, encoder.transform(encoder.classes_)))
		# print(mapping)
		df_labels = mapping_to_df(mapping)
		df_labels.to_csv(path_encoding_labels + column + '.csv')


	# %% [markdown]
	# ## 4.22 - Findings and conlcusions

	# %% [markdown]
	# Stated Above

	# %% [markdown]
	# ## 4.3 - Normalisation

	# %% [markdown]
	# From our point of view, there's no need to normalise any column.<br/>
	# Normalisation is done when you need to compare the values, but here we don't compare anything.

	# %%
	columns_numerical

	# %% [markdown]
	# ## 4.31 - Findings and conclusions

	# %% [markdown]
	# Stated Above

	# %% [markdown]
	# ## 4.4 - Adding more columns

	# %%
	# Sunday encoede as 6
	# Saturday encoede as 5
	ds['is_weekend'] = ds.apply(
		lambda x: 1 if x.day_of_week in [5, 6] else 0, axis=1)
	# ds['is_weekend'] = ds.apply(lambda x: 1 if x.day_of_week in ['Sunday', 'Saturday'] else 0, axis = 1)

	# %%
	# second_road_class Not Availble encode as 5
	ds['two_roads_accident'] = ds.apply(
		lambda x: 0 if x['second_road_class'] == 5 else 1,  axis=1)
	# ds['two_roads_accident'] = ds.apply(lambda x: 0 if pd.isnull(x['second_road_class']) else 1,  axis = 1)


	# %%
	ds.to_csv('/opt/airflow/data/dataframe_cleaned.csv')
	
