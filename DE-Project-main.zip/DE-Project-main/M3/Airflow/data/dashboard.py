# %%
import plotly.express as px
from dash import Dash, dcc, html, Input, Output

# %%
# import matplotlib.pyplot as plt
# import seaborn as sns
import pandas as pd
# import numpy as np
# import math
import re


def plot():
	# %%
	ds = pd.read_csv('/opt/airflow/data/dataframe_integerated.csv',
					 index_col='accident_index')
	ds_original = pd.read_csv(
		'/opt/airflow/data/1996_Accidents_UK.csv', index_col='accident_index')

	# %%
	# Which vehicle type was involved in the most number of accidents?
	fig1 = px.histogram(ds, x='vehicle_type_label', color='vehicle_type_label',
						title='Vehicle type vs Accident count', labels={'vehicle_type_label': 'Vehicle Type'})
	fig1.update_yaxes(title_text='Accident count')
	fig1

	# %%
	result2 = ds.groupby('vehicle_type_label').number_of_casualties.sum(
	).sort_values(ascending=False)
	result2

	# %%
	# Which vehicle type representing the most number of casualties?
	fig2 = px.histogram(result2, x=result2.index, y=result2.values, color=result2.index, title='Vehicle type vs Number of casualties', labels={
		'vehicle_type_label': 'Vehicle Type', 'y': 'Number of Casualties'})
	fig2

	# %%
	result3 = ds_original['local_authority_district'].value_counts(
	).sort_values(ascending=False).head(10)
	fig3 = px.histogram(result3, x=result3.index, y=result3.values, color=result3.index,
						title='District vs Sum of accidents', labels={'x': 'District', 'y': 'Accident Count'})
	fig3.update_xaxes(title_text='District')
	fig3

	# %%
	# hours = ds.apply(lambda x: re.findall(r"([0-9]+):.+", x.time)[0], axis = 1).value_counts().plot(kind='bar', ylabel='Recorded Accidents', xlabel='Hour')
	hours = ds.apply(lambda x: re.findall(
		r"([0-9]+):.+", x.time)[0], axis=1).value_counts()
	fig4 = px.histogram(hours, x=hours.index, y=hours.values, color=hours.index,
						title='Recorded accidents by Hour', labels={'x': 'Hour', 'y': 'Recorded Accidents'})
	fig4.update_xaxes(title_text='Hour')
	fig4

	# %%
	result4 = ds_original['day_of_week'].value_counts()
	fig5 = px.histogram(result4, x=result4.index, y=result4.values, color=result4.index,
						title='Accidents by Day of week', labels={'x': 'Day of Week', 'y': 'Recorded Accidents'})
	fig5.update_xaxes(title_text='Day of Week')
	fig5

	# %%
	app = Dash()
	app.layout = html.Div([
		html.H1("UK dataset 1996 dashboard", style={'text-align': 'center'}),
		html.Br(),
		html.Div(),
		html.H1("Which vehicle type was involved in the most number of accidents?", style={
				'text-align': 'center'}),
		dcc.Graph(figure=fig1),
		html.Br(),
		html.Div(),
		html.H1("Which vehicle type representing the most number of casualties?", style={
				'text-align': 'center'}),
		dcc.Graph(figure=fig2),
		html.Br(),
		html.Div(),
		html.H1("Top 10 Districts with most accidents",
				style={'text-align': 'center'}),
		dcc.Graph(figure=fig3),
		html.Br(),
		html.Div(),
		html.H1("Which hour of the day had the most recorded accidents?",
				style={'text-align': 'center'}),
		dcc.Graph(figure=fig4),
		html.Br(),
		html.Div(),
		html.H1("Which day of the week had the most recorded accidents?",
				style={'text-align': 'center'}),
		dcc.Graph(figure=fig5),
	])

	# %%
	# app.run_server(debug=False)
	app.run_server(host='0.0.0.0', debug=False)
