import pandas as pd
from os import walk
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

def integerate(csvPath):
# %%
	cleaned_ds = pd.read_csv(csvPath, index_col=0)

	# %%
	vehciels_lot = pd.read_csv('/opt/airflow/data/vehicles_lot.csv', index_col=0)
	vehciels = pd.read_csv('/opt/airflow/data/vehicles.csv', index_col=0)


	# %%
	ds_new = pd.merge(cleaned_ds, vehciels, left_index=True,
					right_index=True, how="left")

	# %%
	ds_new.tail()

	# %%
	ds_new = ds_new.copy().reset_index().merge(vehciels_lot, left_on='vehicle_type', right_on='code', how='left').set_index('accident_index').rename(columns={"label": "vehicle_type_label"})
	ds_new.head()

	# %%
	ds_new.to_csv('/opt/airflow/data/dataframe_integerated.csv')


	# %%
	# Collecting the enceded labesl in one csv file

	# Generate the lookup tables for the encoded columns
	dirpath = "/opt/airflow/data/encoding_labels"
	filenames = []
	filepaths = []
	for (dirpath, dirnames, filenames) in walk(dirpath):
		filenames.extend(filenames)
		break

	filepaths = [dirpath + "/" + filename for filename in filenames]


	df_lot = pd.DataFrame(columns=['Field_Name', 'Label', 'Code'])

	for idx, f in enumerate(filepaths):
		df = pd.read_csv(f)
		df.columns = ['Label', 'Code']
		colName = filenames[idx][:-4]
		df["Field_Name"] = colName
		df_lot = df_lot.append(df)

	#
	ds_weeks_periods = pd.read_csv("/opt/airflow/data/week_start_end.csv")
	x = ds_weeks_periods.apply(
		lambda x:  f"{x['week_start']} - {x['week_end']} ", axis=1)
	x = x.to_frame().reset_index()
	x.columns = ['Code', 'Label']
	x['Field_Name'] = 'week_start_end'
	df_lot = df_lot.append(x)
	#
	x = pd.read_csv("/opt/airflow/data/vehicles_lot.csv")
	x.columns = ["Code", "Label"]
	x["Field_Name"] = "vehicle_type"
	df_lot = df_lot.append(x)

	df_lot.to_csv('/opt/airflow/data/lookup.csv', index=False)
