from airflow import DAG
from airflow.utils.dates import days_ago
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator

import pandas as pd
import numpy as np
# For Label Encoding
from sklearn import preprocessing
import dash
import dash_core_components as dcc
import dash_html_components as html
from sqlalchemy import create_engine
import os
import sys
sys.path.append('/opt/airflow/data/')

import M2
import M1
import dashboard

def clean_dataset(filename):
	if(os.path.isfile('/opt/airflow/data/dataframe_cleaned.csv') and os.path.isfile('/opt/airflow/data/week_start_end.csv')):
		print('[WARN] dataframe_cleaned.csv already exists, skip cleaning')
		return

	M1.clean(filename)
	print("[INFO] Cleaning done")


def encode_load(filename):
	if(os.path.isfile('/opt/airflow/data/lookup.csv') and os.path.isfile('/opt/airflow/data/dataframe_integerated.csv')):
		print(
			'[WARN] dataframe_integerated.csv and lookup.csv already exists, skip integerating')
		return

	M2.integerate(filename)
	print("[INFO] Integeration done")


def create_dashboard(filename):
	dashboard.plot()
	print('dashboard is successful and running on port 8000')


def load_to_postgres(filenames):
	ds, dflot = pd.read_csv(filenames[0]), pd.read_csv(filenames[1])
	engine = create_engine(
		'postgresql://root:root@pgdatabase:5432/mydb')
	if(engine.connect()):
		print('[INFO] Connected succesfully')
	else:
		print('[ERROR] Failed to connect')
		return

	try:
		ds.to_sql(name='UK_Accidents_1996', con=engine, if_exists='fail')
	except ValueError:
		print("[WARN] Table UK_Accidents_1996 already exists aborting")

	try:
		dflot.to_sql(name='lookup_table', con=engine, if_exists='fail')
	except ValueError:
		print("[WARN] Table lookup_table already exists aborting")


default_args = {
	"owner": "airflow",
	"depends_on_past": False,
	'start_date': days_ago(2),
	"retries": 1,
}

dag = DAG(
	'uk_1996_pipeline',
	default_args=default_args,
	description='uk 1996 pipeline',
)
with DAG(
		dag_id='uk_1996_pipeline',
		schedule_interval='@once',
		default_args=default_args,
		tags=['uk1996-pipeline'],
)as dag:
	extract_clean_task = PythonOperator(
		task_id='clean_dataset',
		python_callable=clean_dataset,
		op_kwargs={
			"filename": '/opt/airflow/data/1996_Accidents_UK.csv'
		},
	)
	encoding_load_task = PythonOperator(
		task_id='integerate_dataset',
		python_callable=encode_load,
		op_kwargs={
			"filename": "/opt/airflow/data/dataframe_cleaned.csv"
		},
	)
	load_to_postgres_task = PythonOperator(
		task_id='load_to_postgres',
		python_callable=load_to_postgres,
		op_kwargs={
			"filenames": ["/opt/airflow/data/dataframe_integerated.csv", "/opt/airflow/data/lookup.csv"]
		},
	)
	create_dashboard_task = PythonOperator(
	    task_id='create_dashboard',
	    python_callable=create_dashboard,
	    op_kwargs={
	        "filename": '/opt/airflow/data/1996_Accidents_UK.csv'
	    },
	)

	extract_clean_task >> encoding_load_task >> load_to_postgres_task >> create_dashboard_task
