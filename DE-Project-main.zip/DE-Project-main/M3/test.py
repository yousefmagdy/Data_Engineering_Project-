from sqlalchemy import create_engine
import pandas as pd

df = pd.read_csv('lookup.csv')
# df = pd.read_csv('dataframe_integerated.csv')

engine = create_engine(
    'postgresql://root:root@localhost:5432/titanic_etl')

if(engine.connect()):
    print('[INFO] connected succesfully')
else:
    print('[INFO] failed to connect')

res = engine.execute("SELECT * FROM lookup_table").fetchall()
print(res)


# df.to_sql(name = 'titanic_passengers',con = engine,if_exists='replace')
# try:
#     df.to_sql(name='lookup_table', con=engine, if_exists='fail')
# except ValueError:
#     print("[WARN] Table Already Exists Aborting")
